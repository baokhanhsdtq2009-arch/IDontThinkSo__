# Block Blast - Current Project Context

## Current architecture
main.py -> core.game.Game -> core.state_manager.StateManager -> current State -> Board

## Folder structure
- core/: game framework and shared systems
- states/: game states
- gameplay/: gameplay logic

## Current screen
- 1200 x 800

## Current Board
- 10 rows x 10 columns
- board_size = 600
- cell_size = 60
- offset_x = 300
- offset_y = 100
- empty cell value = 0
- empty cell fill = black
- occupied cell fill = white
- normal border = purple
- hover border = green

## Board coordinate logic
- mouse_to_cell(mouse_pos) converts the mouse position into (row, col)
- is_inside(row, col) checks whether the cell belongs to the board
- update_hover(mouse_pos) stores the current hover cell in hover_cell
- draw(screen) only displays the board and hover state

## Current PlayState
- owns a Board instance
- update() gets pygame.mouse.get_pos() and passes it to Board.update_hover()
- draw() clears the screen and calls Board.draw(screen)
- handle_event() is currently empty

## Gameplay work still to build
1. Shape representation and shape list
2. Dragging a shape
3. Mapping a dragged shape to the nearest board cell
4. Checking whether a shape placement is valid
5. Showing a semi-transparent placement preview
6. Placing the shape on mouse release
7. Rejecting invalid placement
8. Clearing completed rows/columns
9. Scoring
10. Board/shape color changes as needed

## Shapes discussed
- 2x2
- 3x3
- L shapes with rotations/reflections as required
- 1-cell dot
- 2-cell adjacent
- 2-cell diagonal
- 3-cell diagonal
- short L (3 cells, right angle)
- horizontal/vertical 4-cell line
- horizontal/vertical 5-cell line
- short T
- long L (right angle)

## Important design decision
The mouse position is currently centralized through Board.update_hover() for the Board. If input handling is generalized later, change it with minimal impact rather than duplicating mouse-position calculations across Board methods.

## Code style preference
Keep related lines compact rather than spreading simple expressions across many lines. Prefer parameters/state values over unnecessary hard-coded values when appropriate.
