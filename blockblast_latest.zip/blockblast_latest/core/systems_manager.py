class SystemsManager:

    def __init__(self):
        self.systems = []

    def add_system(self, system):
        self.systems.append(system)

    def update(self):
        for system in self.systems:
            if hasattr(system, "update"):
                system.update()

    def draw(self, screen):
        for system in self.systems:
            if hasattr(system, "draw"):
                system.draw(screen)
