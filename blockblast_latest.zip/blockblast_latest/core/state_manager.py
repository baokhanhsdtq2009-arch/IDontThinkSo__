class StateManager:

    def __init__(self):
        self.states = {}
        self.current_state = None

    def add_state(self, name, state):
        self.states[name] = state

    def set_state(self, name):
        if name in self.states:
            self.current_state = self.states[name]

    def update(self):
        if self.current_state is not None:
            self.current_state.update()

    def draw(self, screen):
        if self.current_state is not None:
            self.current_state.draw(screen)

    def handle_event(self, event):
        if self.current_state is not None:
            self.current_state.handle_event(event)
