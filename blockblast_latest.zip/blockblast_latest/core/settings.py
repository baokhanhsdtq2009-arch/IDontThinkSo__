class Settings:

    def __init__(self):
        self.width = 1200
        self.height = 800
        self.fps = 60

        self.text_color = (255, 255, 255)
        self.cell_color = (60, 120, 255)
        self.cell_border_color = (255, 255, 255)
        self.cell_border_width = 2
